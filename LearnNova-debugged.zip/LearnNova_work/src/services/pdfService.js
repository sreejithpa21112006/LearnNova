import * as pdfjsLib from 'pdfjs-dist';

// Use the worker shipped with pdfjs-dist instead of a version-sensitive CDN URL.
// This keeps PDF parsing working when the app is offline or a CDN is blocked.
try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url
  ).toString();
} catch (e) {
  console.warn('Could not configure the local PDF.js worker:', e);
}

/**
 * Heuristic patterns that typically indicate a section heading in academic/technical PDFs:
 * - All-caps short lines (e.g., "INTRODUCTION", "RESULTS")
 * - Numbered headings (e.g., "1.", "2.1", "Section 3")
 * - Title-case short lines that end without punctuation
 */
function looksLikeHeading(line) {
  const trimmed = line.trim();
  if (!trimmed || trimmed.length > 80) return false;

  // Numbered headings: "1.", "2.1", "3.1.2", "Section 1", "CHAPTER 2"
  if (/^(section|chapter|part)\s+\d+/i.test(trimmed)) return true;
  if (/^\d+(\.\d+)*\.?\s+[A-Z]/.test(trimmed)) return true;

  // All-caps short phrases (e.g., "ABSTRACT", "INTRODUCTION")
  if (/^[A-Z][A-Z\s\-]{2,40}$/.test(trimmed) && trimmed.split(' ').length <= 5) return true;

  // Title-case line that doesn't end with sentence-ending punctuation and is short
  if (
    trimmed.length < 60 &&
    !/[.?!,;]$/.test(trimmed) &&
    /^[A-Z]/.test(trimmed) &&
    !/^\s*(the|a|an|in|on|at|to|for|of|and|but|or|because|when|while)\s/i.test(trimmed)
  ) {
    const wordCount = trimmed.split(/\s+/).length;
    if (wordCount >= 2 && wordCount <= 7) return true;
  }

  return false;
}

/**
 * Extracts clean text from an uploaded PDF File or ArrayBuffer.
 * Intelligently detects section headings within the raw text and emits
 * markdown H2 headings so the downstream chunkingService can split on them.
 *
 * @param {File | ArrayBuffer} fileOrBuffer
 * @returns {Promise<{ text: string, numPages: number, title: string, isScannedLikely: boolean }>}
 */
export async function extractTextFromPdf(fileOrBuffer) {
  let arrayBuffer;
  let filename = "Uploaded Document.pdf";

  if (fileOrBuffer instanceof File) {
    filename = fileOrBuffer.name;
    arrayBuffer = await fileOrBuffer.arrayBuffer();
  } else {
    arrayBuffer = fileOrBuffer;
  }

  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;
  const numPages = pdf.numPages;

  // Step 1: Extract all text content while preserving page boundaries.
  // Keeping pages separate lets the fallback chunker create real page sections
  // instead of guessing boundaries after the information has already been lost.
  const pageLines = [];
  let totalChars = 0;

  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const textContent = await page.getTextContent();

    const lineMap = new Map();
    for (const item of textContent.items) {
      if (!item.str) continue;
      const y = Math.round(item.transform[5] / 4) * 4;
      if (!lineMap.has(y)) lineMap.set(y, []);
      lineMap.get(y).push(item);
    }

    const sortedYs = Array.from(lineMap.keys()).sort((a, b) => b - a);
    const lines = [];

    for (const y of sortedYs) {
      const items = lineMap.get(y).sort((a, b) => a.transform[4] - b.transform[4]);
      const lineText = items.map(i => i.str).join(' ').trim();
      if (lineText) {
        lines.push(lineText);
        totalChars += lineText.length;
      }
    }

    pageLines.push(lines);
  }

  // Step 2: Merge lines into paragraphs and detect headings, page by page.
  const pageParts = [];
  let detectedHeadings = 0;

  for (const lines of pageLines) {
    const outputParts = [];
    let currentParagraph = [];

    for (const line of lines) {
      if (looksLikeHeading(line)) {
        if (currentParagraph.length > 0) {
          outputParts.push(currentParagraph.join(' '));
          currentParagraph = [];
        }
        outputParts.push(`## ${line.trim()}`);
        detectedHeadings++;
      } else {
        currentParagraph.push(line);
      }
    }

    if (currentParagraph.length > 0) {
      outputParts.push(currentParagraph.join(' '));
    }

    pageParts.push(outputParts);
  }

  // Step 3: Build markdown while retaining actual page boundaries.
  // If headings exist, use them as logical sections. Otherwise, expose each
  // page as a section so long/scanned PDFs remain navigable.
  const hasUsefulContent = pageParts.some(parts => parts.length > 0);
  let fullText;

  if (!hasUsefulContent) {
    fullText = '';
  } else if (detectedHeadings > 0) {
    fullText = pageParts
      .map(parts => parts.join('\n\n'))
      .filter(Boolean)
      .join('\n\n');
  } else {
    fullText = pageParts
      .map((parts, index) => (
        parts.length > 0
          ? `## Page ${index + 1}\n\n${parts.join('\n\n')}`
          : ''
      ))
      .filter(Boolean)
      .join('\n\n');
  }

  // Scanned PDF detection: if average chars per page < 50, likely scanned images
  const avgCharsPerPage = totalChars / (numPages || 1);
  const isScannedLikely = avgCharsPerPage < 50;

  // Clean document title from filename
  const cleanTitle = filename.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');

  return {
    text: fullText.trim(),
    numPages,
    title: cleanTitle,
    isScannedLikely
  };
}

/**
 * Renders pages of a PDF to high-resolution JPEG Data URLs for Vision OCR
 * @param {File | ArrayBuffer} fileOrBuffer
 * @param {number} maxPages - Max pages to render (default 10)
 * @param {number} scale - Render scale factor (default 1.8 for optimal OCR legibility)
 * @returns {Promise<Array<string>>} Array of base64 data URLs
 */
export async function renderPdfPagesToImages(fileOrBuffer, maxPages = 10, scale = 1.8) {
  let arrayBuffer;
  if (fileOrBuffer instanceof File) {
    arrayBuffer = await fileOrBuffer.arrayBuffer();
  } else {
    arrayBuffer = fileOrBuffer;
  }

  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;
  const numPagesToRender = Math.min(pdf.numPages, maxPages);
  const images = [];

  for (let pageNum = 1; pageNum <= numPagesToRender; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    const renderContext = {
      canvasContext: context,
      viewport: viewport
    };

    await page.render(renderContext).promise;
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    images.push(dataUrl);
  }

  return images;
}
