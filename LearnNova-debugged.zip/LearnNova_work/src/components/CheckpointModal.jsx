import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  BookOpen, 
  HelpCircle,
  BookmarkPlus
} from 'lucide-react';
import confetti from 'canvas-confetti';
import MascotSvg from './Mascot/MascotSvg';
import { speakMascotVoice } from '../services/tutorService';

export default function CheckpointModal({
  checkpointData,
  onComplete,
  onClose
}) {
  const [selectedOption, setSelectedOption] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);

  if (!checkpointData) return null;

  const {
    question,
    options = [],
    correctIndex = 0,
    explanation,
    chunkTitle,
    chunkIndex
  } = checkpointData;

  const isCorrect = selectedOption === correctIndex;

  const handleSelectOption = (idx) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    if (idx === correctIndex) {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch (e) {}
    }
  };

  const handleContinue = () => {
    onComplete({
      chunkIndex,
      chunkTitle,
      question,
      options,
      correctIndex,
      userAnswerIndex: selectedOption,
      isCorrect,
      explanation
    });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '640px' }}>
        {/* Header Badge */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
          <span className="checkpoint-badge">
            <Sparkles size={14} /> Section Checkpoint
          </span>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
            Section {chunkIndex + 1}: {chunkTitle}
          </span>
        </div>

        {/* Question Title */}
        <h2 className="checkpoint-question">{question}</h2>

        {/* Option Selectors */}
        <div className="checkpoint-options">
          {options.map((opt, idx) => {
            let stateClass = '';
            if (isAnswered) {
              if (idx === correctIndex) stateClass = 'selected-correct';
              else if (idx === selectedOption) stateClass = 'selected-wrong';
            }

            return (
              <button
                key={idx}
                className={`checkpoint-option-btn ${stateClass}`}
                onClick={() => handleSelectOption(idx)}
                disabled={isAnswered}
              >
                <span className="checkpoint-opt-letter">
                  {String.fromCharCode(65 + idx)}
                </span>
                <span style={{ flex: 1 }}>{opt}</span>
                {isAnswered && idx === correctIndex && (
                  <CheckCircle2 size={16} color="var(--green)" />
                )}
                {isAnswered && idx === selectedOption && idx !== correctIndex && (
                  <XCircle size={16} color="var(--red)" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback & Explanation with Mascot */}
        {isAnswered && (
          <div className="checkpoint-explanation" style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
            <div style={{ flexShrink: 0, marginTop: '4px' }}>
              <MascotSvg state={isCorrect ? 'cheering' : 'thinking'} size={48} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                {isCorrect ? (
                  <strong style={{ color: 'var(--green)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <CheckCircle2 size={16} /> Spot on!
                  </strong>
                ) : (
                  <strong style={{ color: 'var(--red)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <XCircle size={16} /> Key Concept to Reinforce
                  </strong>
                )}
                <span style={{ fontSize: '0.76rem', color: 'var(--accent)', marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <BookmarkPlus size={13} /> Queued for Spaced Repetition Deck
                </span>
              </div>
              <p style={{ margin: 0, fontSize: '0.84rem', lineHeight: 1.5 }}>{explanation}</p>
            </div>
          </div>
        )}

        {/* Modal Actions */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '12px', marginTop: '24px' }}>
          <button 
            className="btn btn-ghost"
            onClick={onClose}
          >
            Skip for Now
          </button>

          <button 
            className="btn btn-primary"
            onClick={handleContinue}
            disabled={!isAnswered}
          >
            <span>Continue Reading</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
